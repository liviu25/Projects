package ro.axonsoft.internship.api;

public class ReaderException extends Exception {
    public ReaderException() {
    }

    public ReaderException(String message) {
        super(message);
    }
}
